# Sample WoCommerce Rest API example

## References

https://docs.woocommerce.com/document/woocommerce-rest-api/

https://packagist.org/packages/automattic/woocommerce

https://woocommerce.github.io/woocommerce-rest-api-docs/?php
