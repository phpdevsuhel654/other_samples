<?php

require __DIR__ . '/vendor/autoload.php';

use Automattic\WooCommerce\Client;

echo '<h1>Get WoCommerce Object</h1>';

$woocommerce = new Client(
    'http://localhost/rnd/wordpress_wc_sample', 
    'ck_d0359b2fe4c2d7bf14178f646569555aae3bb63a', 
    'cs_1fa77b2eadbb2e839ff0daabcb9781c76d44abab',
    [
        'version' => 'wc/v3',
    ]
);

echo '<pre>'; print_r($woocommerce); exit();